package com.example.cancer_prevention.Retrofit

class Cancer_address {

    companion object{
        const val BASE_URL = "https://api.odcloud.kr/"
    }
}