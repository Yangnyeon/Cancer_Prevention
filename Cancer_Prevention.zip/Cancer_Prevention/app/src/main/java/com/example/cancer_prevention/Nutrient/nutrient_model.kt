package com.example.cancer_prevention.Nutrient

data class nutrient_model(val Nutrient_Image : String , val Nutrient_Name : String)
{
    constructor() : this(
        "",
        ""
    )

}