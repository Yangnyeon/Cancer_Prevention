package com.example.cancer_prevention.room

interface OnItemClick {
    fun deleteTodo(cigarette: Cigarette)
}