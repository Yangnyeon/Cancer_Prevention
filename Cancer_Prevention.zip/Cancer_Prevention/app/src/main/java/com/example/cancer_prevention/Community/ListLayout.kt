package com.example.cancer_prevention.Community

data class ListLayout(val name: String = "", val number: String = "", val com_date: String = "", val password: String = "", val doc: String = "", var Nickname : String = "", var liked : Long = 0, var eye : Long = 0,  var imageUrl:String ?= null)
