package com.example.cancer_prevention.Main.Notice

class Notice_Layout(val notice_name: String, val notice_content : String? ,val notice_date: String?, val notice_doc: String,  var notice_imageUrl:String ?= null)