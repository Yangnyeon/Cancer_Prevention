package com.example.cancer_prevention.Community.Comment

class Comment_ListLayout(val Comment: String, val Date: String, val Doc: String, val comment_password : String, val content_doc : String, val Content_nickname : String, val Comment_liked : Long)